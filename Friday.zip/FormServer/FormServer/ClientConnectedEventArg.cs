﻿using FormServerSocket;

namespace FormServer
{
    internal class ClientConnectedEventArg : ClientConnectedEventArgs
    {
        private bool v;

        public ClientConnectedEventArg(bool v)
        {
            this.v = v;
        }
    }
}