﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using FormServerSocket;

namespace FormServer
{
    public partial class Form1 : Form
    {
        List<string> mylist = new List<string> { };
       
        FormServerSockets mServer;
        public Form1()
        { 
            InitializeComponent();
            mServer = new FormServerSockets();
            mServer.RaiseClientConnectedEvent += HandleClientConnected;
            mServer.RaiseTextReceivedEvent += HandleTextReceived;
            mServer.RaiseClientDisconnectedEvent += HandleClientDisconnected;
        }

        private void btnIncommingClientConnect_Click(object sender, EventArgs e)
        {
            mServer.StartListeningForIncomingConnection();
        }

        private void btnSendAll_Click(object sender, EventArgs e)
        {
            mServer.SendToAll(textMessage.Text.Trim());
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            mServer.StopServer();
        }
        string message { get; set; }
      
        public void HandleTextReceived(object sender, TextReceivedEventArgs trea)
        {
            
            message = trea.TextReceived ;
            //txtConsole.AppendText( string.Format($"{0} - Received from {2}: {1}{3}",DateTime.Now, trea.TextReceived, trea.ClientWhoSentText, Environment.NewLine));
           
            
                txtConsole.AppendText(string.Format($"{trea.TextReceived},{Environment.NewLine}"));
            
        }
        int count = 0;
        int again = 0;
        string list { get; set; } 
        public void HandleClientConnected(object sender, ClientConnectedEventArgs ccea)
        {
           list = ccea.NewClient;
            List<string> lb = new List<string>();
            lb.Add(ccea.NewClient);
            count++;
            if (count == 2)
                {
                    lbClients.Items.Add(string.Format($"Connected : {message}"));
                    txtConsole.Clear();
                    count = again;
            }
            
            string abc = message;

        }

        //for ip and port add this command {ccea.NewClient}
        // { Environment.NewLine}
       
        void HandleClientDisconnected(object sender, ConnectionDisconnectedEventArgs cdea)
        {
            
  
                if (lbClients.IsDisposed)
                {
                    try
                    {
                        lbClients.Items.RemoveAt(count);

                    }
                    catch (Exception excp)
                    {

                        lbClients.Items.Add(excp.ToString());
                    }
                }
           
        }
    }
}
 //lbClients.Items.Remove(cn.ToString());
