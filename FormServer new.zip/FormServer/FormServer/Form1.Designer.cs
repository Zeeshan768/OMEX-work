﻿
namespace FormServer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIncommingClientConnect = new System.Windows.Forms.Button();
            this.btnSendAll = new System.Windows.Forms.Button();
            this.textMessage = new System.Windows.Forms.TextBox();
            this.txtConsole = new System.Windows.Forms.TextBox();
            this.LbClients = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnIncommingClientConnect
            // 
            this.btnIncommingClientConnect.Location = new System.Drawing.Point(92, 316);
            this.btnIncommingClientConnect.Name = "btnIncommingClientConnect";
            this.btnIncommingClientConnect.Size = new System.Drawing.Size(158, 33);
            this.btnIncommingClientConnect.TabIndex = 0;
            this.btnIncommingClientConnect.Text = "Accept Incoming Client";
            this.btnIncommingClientConnect.UseVisualStyleBackColor = true;
            this.btnIncommingClientConnect.Click += new System.EventHandler(this.btnIncommingClientConnect_Click);
            // 
            // btnSendAll
            // 
            this.btnSendAll.Location = new System.Drawing.Point(136, 287);
            this.btnSendAll.Name = "btnSendAll";
            this.btnSendAll.Size = new System.Drawing.Size(75, 23);
            this.btnSendAll.TabIndex = 1;
            this.btnSendAll.Text = "&Send All";
            this.btnSendAll.UseVisualStyleBackColor = true;
            this.btnSendAll.Click += new System.EventHandler(this.btnSendAll_Click);
            // 
            // textMessage
            // 
            this.textMessage.Location = new System.Drawing.Point(107, 261);
            this.textMessage.Name = "textMessage";
            this.textMessage.Size = new System.Drawing.Size(143, 20);
            this.textMessage.TabIndex = 2;
            // 
            // txtConsole
            // 
            this.txtConsole.Location = new System.Drawing.Point(-3, 35);
            this.txtConsole.Multiline = true;
            this.txtConsole.Name = "txtConsole";
            this.txtConsole.Size = new System.Drawing.Size(597, 212);
            this.txtConsole.TabIndex = 4;
            // 
            // LbClients
            // 
            this.LbClients.FormattingEnabled = true;
            this.LbClients.Location = new System.Drawing.Point(615, 35);
            this.LbClients.Name = "LbClients";
            this.LbClients.Size = new System.Drawing.Size(133, 212);
            this.LbClients.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(641, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Connected Clients";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 350);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LbClients);
            this.Controls.Add(this.txtConsole);
            this.Controls.Add(this.textMessage);
            this.Controls.Add(this.btnSendAll);
            this.Controls.Add(this.btnIncommingClientConnect);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIncommingClientConnect;
        private System.Windows.Forms.Button btnSendAll;
        private System.Windows.Forms.TextBox textMessage;
        private System.Windows.Forms.TextBox txtConsole;
        private System.Windows.Forms.ListBox LbClients;
        private System.Windows.Forms.Label label1;
    }
}

