﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using FormServerSocket;

namespace FormServer
{
    public partial class Form1 : Form
    {
        FormServerSockets mServer;
        public Form1()
        {
            InitializeComponent();
            mServer = new FormServerSockets();
            mServer.RaiseClientConnectedEvent += HandleClientConnected;
            mServer.RaiseTextReceivedEvent += HandleTextReceived;
            mServer.RaiseClientDisconnectedEvent += HandleClientDisconnected;
        }

        private void btnIncommingClientConnect_Click(object sender, EventArgs e)
        {
            mServer.StartListeningForIncomingConnection();
        }

        private void btnSendAll_Click(object sender, EventArgs e)
        {
            mServer.SendToAll(textMessage.Text.Trim());
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            mServer.StopServer();
        }
        void HandleClientConnected(object sender, ClientConnectedEventArgs ccea)
        {
            lbClients.Items.Add(String.Format($"Client {ccea.NewClient} connected"));
            
            //for ip and port add this command {ccea.NewClient}
         // { Environment.NewLine}
        }
        void HandleTextReceived(object sender, TextReceivedEventArgs trea)
        {
            txtConsole.AppendText(string.Format($"{ trea.TextReceived}:{trea.ClientWhoSentText}"));
        }
        void HandleClientDisconnected(object sender, ConnectionDisconnectedEventArgs cdea)
        {
            
            if (!lbClients.IsDisposed)
                try
                {      
                   lbClients.Items.RemoveAt(0);
                }
                catch (Exception excp)
                {

                    lbClients.Items.Add(excp.ToString());
                }
           
        }
    }
}
 //lbClients.Items.Remove(cn.ToString());
