﻿namespace FormServer
{
    internal class TextRecievedEventArgs
    {
    }
}