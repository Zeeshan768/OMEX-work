﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using SimpleTcp;

namespace TCPServer
{
    public partial class TCPServer : Form
    {

        public TCPServer()
        {
            InitializeComponent();
        }

        SimpleTcpServer server;

        public int Evnet_DataRecieved { get; private set; }

        private void btnStart_Click(object sender, EventArgs e)
        {
            server.Start();
            txtInfo.Text += $"Starting...{Environment.NewLine}";
            btnStart.Enabled = false;
            btnSend.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnSend.Enabled = false;
            server = new SimpleTcpServer(txtIP.Text);
            server.Events.ClientConnected += Evnet_ClientConnected;
            server.Events.ClientDisconnected += Evnet_ClientDisconnected;
            server.Events.DataReceived += Events_DataReceived;
        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Evnet_ClientConnected(object sender, ConnectionEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Evnet_ClientDisconnected(object sender, ConnectionEventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
//https://www.youtube.com/watch?v=QrdfegS3iDg