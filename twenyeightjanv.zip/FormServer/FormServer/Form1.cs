﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using FormServerSocket;

namespace FormServer
{
    public partial class Form1 : Form
    {
        string[] name = {"Zeeshan" , "Farhan" , "Arman"};
        FormServerSockets mServer;
        public Form1()
        {
            InitializeComponent();
            mServer = new FormServerSockets();
            mServer.RaiseClientConnectedEvent += HandleClientConnected;
            mServer.RaiseTextReceivedEvent += HandleTextReceived;
            mServer.RaiseClientDisconnectedEvent += HandleClientDisconnected;
        }

        private void btnIncommingClientConnect_Click(object sender, EventArgs e)
        {
            mServer.StartListeningForIncomingConnection();
        }

        private void btnSendAll_Click(object sender, EventArgs e)
        {
            mServer.SendToAll(textMessage.Text.Trim());
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            mServer.StopServer();
        }
        int count = 0;
        string message { get; set; }
        public void HandleTextReceived(object sender, TextReceivedEventArgs trea)
        {
                        message = trea.TextReceived;

            //txtConsole.AppendText( string.Format($"{0} - Received from {2}: {1}{3}",DateTime.Now, trea.TextReceived, trea.ClientWhoSentText, Environment.NewLine));
            txtConsole.AppendText(string.Format($"{trea.TextReceived},{Environment.NewLine}"));
        }
        public void HandleClientConnected(object sender, ClientConnectedEventArgs ccea)
        {
            lbClients.Items.Add(string.Format($"{ccea.NewClient} {message} {Environment.NewLine} connected"));
            string abc = message;
             
         }

        //for ip and port add this command {ccea.NewClient}
        // { Environment.NewLine}
       
        void HandleClientDisconnected(object sender, ConnectionDisconnectedEventArgs cdea)
        {
            
            if (!lbClients.IsDisposed)
                try
                {      
                   lbClients.Items.RemoveAt(0);
                }
                catch (Exception excp)
                {

                    lbClients.Items.Add(excp.ToString());
                }
           
        }
    }
}
 //lbClients.Items.Remove(cn.ToString());
