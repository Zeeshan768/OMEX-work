﻿
namespace FormServer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIncommingClientConnect = new System.Windows.Forms.Button();
            this.btnSendAll = new System.Windows.Forms.Button();
            this.textMessage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtConsole = new System.Windows.Forms.TextBox();
            this.lbClients = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnIncommingClientConnect
            // 
            this.btnIncommingClientConnect.Location = new System.Drawing.Point(48, 349);
            this.btnIncommingClientConnect.Name = "btnIncommingClientConnect";
            this.btnIncommingClientConnect.Size = new System.Drawing.Size(331, 70);
            this.btnIncommingClientConnect.TabIndex = 0;
            this.btnIncommingClientConnect.Text = "Accept Incoming Client";
            this.btnIncommingClientConnect.UseVisualStyleBackColor = true;
            this.btnIncommingClientConnect.Click += new System.EventHandler(this.btnIncommingClientConnect_Click);
            // 
            // btnSendAll
            // 
            this.btnSendAll.Location = new System.Drawing.Point(152, 308);
            this.btnSendAll.Name = "btnSendAll";
            this.btnSendAll.Size = new System.Drawing.Size(75, 23);
            this.btnSendAll.TabIndex = 1;
            this.btnSendAll.Text = "&Send All";
            this.btnSendAll.UseVisualStyleBackColor = true;
            this.btnSendAll.Click += new System.EventHandler(this.btnSendAll_Click);
            // 
            // textMessage
            // 
            this.textMessage.Location = new System.Drawing.Point(99, 270);
            this.textMessage.Name = "textMessage";
            this.textMessage.Size = new System.Drawing.Size(191, 20);
            this.textMessage.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 277);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Type Message";
            // 
            // txtConsole
            // 
            this.txtConsole.Location = new System.Drawing.Point(12, 12);
            this.txtConsole.Multiline = true;
            this.txtConsole.Name = "txtConsole";
            this.txtConsole.Size = new System.Drawing.Size(527, 242);
            this.txtConsole.TabIndex = 4;
            // 
            // lbClients
            // 
            this.lbClients.FormattingEnabled = true;
            this.lbClients.Location = new System.Drawing.Point(555, 14);
            this.lbClients.Name = "lbClients";
            this.lbClients.Size = new System.Drawing.Size(233, 329);
            this.lbClients.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbClients);
            this.Controls.Add(this.txtConsole);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textMessage);
            this.Controls.Add(this.btnSendAll);
            this.Controls.Add(this.btnIncommingClientConnect);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIncommingClientConnect;
        private System.Windows.Forms.Button btnSendAll;
        private System.Windows.Forms.TextBox textMessage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtConsole;
        private System.Windows.Forms.ListBox lbClients;
    }
}

