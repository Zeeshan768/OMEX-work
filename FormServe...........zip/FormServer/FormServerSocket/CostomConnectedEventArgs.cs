﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net.Sockets;
using System.IO;

namespace FormServerSocket
{
    public class ClientConnectedEventArgs : EventArgs
    {
        public string NewClient { get; set; }

        public ClientConnectedEventArgs(string _newClient)
        {
            NewClient = _newClient;
        }
    } 
    public class TextRecievedEventArgs : EventArgs
    {
        public string ClientWhoSentText { get; set; }
        public string TextRecieved { get; set; }
        

        public TextRecievedEventArgs(string _clientWhoSentText, string _textRecieved)
        
        {
            ClientWhoSentText= _clientWhoSentText;  
            TextRecieved= _textRecieved;    
        }
        
    }
}