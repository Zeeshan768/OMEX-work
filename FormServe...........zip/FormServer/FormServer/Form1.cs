﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FormServerSocket;

namespace FormServer
{
    public partial class Form1 : Form
    {
        FormServerSockets mServer;
        public Form1()
        {
            InitializeComponent();
            mServer = new FormServerSockets();
            mServer.RaiseClientConnectedEvent += HandleClientConnected;
            mServer.RaiseTextRecievedEvent += HandleTextRecieved;   
        }

        private void btnIncommingClientConnect_Click(object sender, EventArgs e)
        {
            mServer.StartListeningForIncommingConnection();
        }

        private void btnSendAll_Click(object sender, EventArgs e)
        {
            mServer.SendToAll(textMessage.Text.Trim());
        }
        void HandleClientConnected(object sender, ClientConnectedEventArgs ccea)
        {
            txtConsole.AppendText(String.Format($"{DateTime.Now} New client connected : {ccea.NewClient} {Environment.NewLine}"));
        }
        void HandleTextRecieved(object sender, TextRecievedEventArgs trea)
        {
            txtConsole.AppendText(string.Format($"{DateTime.Now}: {trea.TextRecieved}{Environment.NewLine} : {trea.ClientWhoSentText}"));
        }
    }
}
