﻿using System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace TCP_CLient
{
    public partial class Form1 : Form
    {
        TcpClient mTcpClient;
        byte[] mRx;
        int nPort;
        IPAddress ipa;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Conn_Click(object sender, EventArgs e)
        {
            
                try
                {
                    if (string.IsNullOrEmpty(txtipaddress.Text) || string.IsNullOrEmpty(txtport.Text))
                        return;
                    if (!IPAddress.TryParse(txtipaddress.Text, out ipa))
                    {
                        MessageBox.Show("Please supply an IP Address.");
                        return;
                    }

                    if (!int.TryParse(txtport.Text, out nPort))
                    {
                        nPort = 23000;
                    }

                    mTcpClient = new TcpClient();
                    mTcpClient.BeginConnect(ipa, nPort, onCompleteConnect, mTcpClient);
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
            
           
            //IPAddress ipa;
            //int port = 22222;
            //port = int.Parse(txtport.Text);
            //IPEndPoint endpoint = new IPEndPoint(IPAddress.Parse(txtport.Text), port);

           
        }
        void onCompleteConnect(IAsyncResult iar)
        {
            TcpClient tcpc;

            try
            {
                tcpc = (TcpClient)iar.AsyncState;
                tcpc.EndConnect(iar);
                mRx = new byte[512];
                tcpc.GetStream().BeginRead(mRx, 0, mRx.Length, onCompleteReadFromServerStream, tcpc);

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        void onCompleteReadFromServerStream(IAsyncResult iar)
        {
            TcpClient tcpc;
            int nCountBytesReceivedFromServer;
            string strReceived;

            try
            {
                tcpc = (TcpClient)iar.AsyncState;
                nCountBytesReceivedFromServer = tcpc.GetStream().EndRead(iar);

                if (nCountBytesReceivedFromServer == 0)
                {
                    MessageBox.Show("Connection broken.");
                    return;
                }
                strReceived = Encoding.ASCII.GetString(mRx, 0, nCountBytesReceivedFromServer);

                printLine(strReceived);

                mRx = new byte[512];
                tcpc.GetStream().BeginRead(mRx, 0, mRx.Length, onCompleteReadFromServerStream, tcpc);

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
       

        public void printLine(string _strPrint)
        {
            tbConsole.Invoke(new Action<string>(doInvoke), _strPrint);
        }

        public void doInvoke(string _strPrint)
        {
            tbConsole.Text = _strPrint + Environment.NewLine + tbConsole.Text;
        }

        private void Send_Click(object sender, EventArgs e)
        {
            byte[] tx;

            if (string.IsNullOrEmpty(txtMessages.Text)) return;

            try
            {
                tx = Encoding.ASCII.GetBytes(txtMessages.Text);
                //tx = Encoding.ASCII.GetBytes("Port: "+ nPort + txtMessages.Text);

                if (mTcpClient != null)
                {
                    if (mTcpClient.Client.Connected)
                    {
                        mTcpClient.GetStream().BeginWrite(tx, 0, tx.Length, onCompleteWriteToServer, mTcpClient);
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
        void onCompleteWriteToServer(IAsyncResult iar)
        {
            TcpClient tcpc;

            try
            {
                tcpc = (TcpClient)iar.AsyncState;
                tcpc.GetStream().EndWrite(iar);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            byte[] tx,xy;

            if (string.IsNullOrEmpty(txtuser.Text) && string.IsNullOrEmpty(txtpassword.Text)) 
                return;

            try
            {
                tx = Encoding.ASCII.GetBytes(txtuser.Text);
                xy = Encoding.ASCII.GetBytes(txtpassword.Text);
                //tx = Encoding.ASCII.GetBytes("Port: "+ nPort + txtMessages.Text);

                if (mTcpClient != null)
                {
                    if (mTcpClient.Client.Connected)
                    {
                        mTcpClient.GetStream().BeginWrite(tx, 0, tx.Length, onCompleteWriteToServer, mTcpClient);
                        mTcpClient.GetStream().BeginWrite(xy, 0, xy.Length, onCompleteWriteToServer, mTcpClient);
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }

        }
    }
}
