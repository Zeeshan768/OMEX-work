﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net.Sockets;
using System.Net;
using FormServerSocket;
using System.Threading;

namespace TCP_Server
{
    public partial class Form1 : Form
    {
        FormServerSockets mServer;
        public Form1()
        {
            InitializeComponent();
            mServer = new FormServerSockets();
            mServer.RaiseClientConnectedEvent += HandleClientConnected;
            mServer.RaiseTextReceivedEvent += HandleTextReceived;
            mServer.RaiseClientDisconnectedEvent += HandleClientDisconnected;

        }
        //public void recevie(IAsyncResult ar, ClientConnectedEventArgs ccea)
        //{
        //    byte[] _buffer = new byte[1500];
        //    Socket socket = (Socket)ar.AsyncState;
        //    int received = socket.EndReceive(ar);
        //    byte[] buffer = new byte[received];
        //    Array.Copy(_buffer, buffer, received);
        //    string txt = Encoding.UTF8.GetString(buffer);
        //    if (txt == "demo" && txt == "1234")
        //    {
        //        listConnection.Items.Add(String.Format($"Client Connected  {ccea.NewClient}"));
        //    }
        //    else
        //    {
        //        MessageBox.Show("Incorrect username and password");
        //    }
        //}
        void HandleClientConnected(object sender, ClientConnectedEventArgs ccea)
        {
            //listConnection.Items.Add(String.Format($"Client Connected  {ccea.NewClient}"));

        }
        void HandleTextReceived(object sender, TextReceivedEventArgs trea)
        {
            if(trea.TextReceived == "demo" && trea.TextReceived == "1234")
            {
                listConnection.Items.Add("Login and add SuccessFully");
            }
            else
            {
                MessageBox.Show("Sorry Try Again");
            }
            listMessage.Items.Add(String.Format($"{trea.NewClient} { trea.TextReceived} {trea.ClientWhoSentText}"));
        }
        void HandleClientDisconnected(object sender, ConnectionDisconnectedEventArgs cdea)
        {

            if (!listConnection.IsDisposed)
                try
                {
                    listConnection.Items.RemoveAt(0);
                }
                catch (Exception excp)
                {

                    listConnection.Items.Add(excp.ToString());
                }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            mServer.StartListeningForIncomingConnection();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mServer.SendToAll(txtMessageSend.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void listMessage_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void Received(IAsyncResult ar, ClientConnectedEventArgs ccea)
        {
            byte[] _buffer = new byte[1500];
            Socket socket = (Socket)ar.AsyncState;
            int received = socket.EndReceive(ar);
            byte[] buffer = new byte[received];
            Array.Copy(_buffer,buffer,received);
            string txt = Encoding.UTF8.GetString(buffer);
            if(txt == "demo" && txt == "1234")
            {
                listConnection.Items.Add(String.Format($"Client Connected  {ccea.NewClient}"));
            }


        }
    }
}
