﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using FormServerSocket;
using System.Net.Sockets;
using System.Net;

namespace FormServer
{
    public partial class Form1 : Form
    {
        FormServerSockets mServer;
        TcpListener mTCPListener;
        TcpClient nTCPClient;
        byte[] nRx;
        public Form1()
        {
            InitializeComponent();
            mServer = new FormServerSockets();
            mServer.RaiseClientConnectedEvent += HandleClientConnected;
            mServer.RaiseTextReceivedEvent += HandleTextReceived;
            mServer.RaiseClientDisconnectedEvent += HandleClientDisconnected;
        }

        private void btnIncommingClientConnect_Click(object sender, EventArgs e)
        {
            mServer.StartListeningForIncomingConnection();
            
        }

        private void btnSendAll_Click(object sender, EventArgs e)
        {
            mServer.SendToAll(textMessage.Text.Trim());
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            mServer.StopServer();
        }
        void HandleClientConnected(object sender, ClientConnectedEventArgs ccea)
        {
            txtConsole.AppendText(String.Format($"{DateTime.Now} New client connected : {ccea.NewClient} {Environment.NewLine}"));
        }
        void HandleTextReceived(object sender, TextReceivedEventArgs trea)
        {
            txtConsole.AppendText(string.Format($"{DateTime.Now}:\n { trea.TextReceived} {Environment.NewLine} : {trea.ClientWhoSentText}"));
        }
        void HandleClientDisconnected(object sender, ConnectionDisconnectedEventArgs cdea)
        {
            if (!txtConsole.IsDisposed)
            {
                txtConsole.AppendText(string.Format($"{DateTime.Now} - Client Disconnected: {cdea.DisconnectedPeer}\r\n"));
            }
        }
        private void btnStartListening_Click(object sender, EventArgs e)
        {
            IPAddress ipaddr;
            int mPort;

            if (!int.TryParse(tbPort.Text, out mPort))
            {
                mPort = 23000;
            }
            if (!IPAddress.TryParse(tbIPAddress.Text, out ipaddr))
            {
                MessageBox.Show("Invalid IP address supplied.");
                return;
            }

            mTCPListener = new TcpListener(ipaddr, mPort);

            mTCPListener.Start();

            mTCPListener.BeginAcceptTcpClient(onCompleteAcceptTcpClient,mTCPListener);

        }
        void onCompleteAcceptTcpClient(IAsyncResult iar)
        {
            TcpListener tcpl = (TcpListener)iar.AsyncState;
            try
            {
                nTCPClient = tcpl.EndAcceptTcpClient(iar);

                printLine("Client Connected...");

                nRx = new byte[512];
                nTCPClient.GetStream().BeginRead(nRx, 0, nRx.Length, onCompleteReadFromTCPClientStream, nTCPClient);

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void onCompleteReadFromTCPClientStream(IAsyncResult iar)
        {
            TcpClient tcpc;
            int nCountReadBytes = 0;
            string strRecv;

            try
            {
                tcpc = (TcpClient)iar.AsyncState;
                nCountReadBytes = tcpc.GetStream().EndRead(iar);

                if (nCountReadBytes == 0)
                {
                    MessageBox.Show("Client disconnected.");
                    return;
                }

                strRecv = Encoding.ASCII.GetString(nRx, 0, nCountReadBytes);

                printLine(strRecv);

                nRx = new byte[512];

                tcpc.GetStream().BeginRead(nRx, 0, nRx.Length, onCompleteReadFromTCPClientStream, tcpc);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void printLine(string _strPrint)
        {
            txtConsole.Invoke(new Action<string>(doInvoke), _strPrint);
        }

        public void doInvoke(string _strPrint)
        {
            txtConsole.Text = _strPrint + Environment.NewLine + txtConsole.Text;
        }
        private void btnSend_Click(object sender, EventArgs e)
        {
            byte[] tx = new byte[512];
            if (string.IsNullOrEmpty(tbPayload.Text))
            {
                return;
            }
            try
            {
                if (nTCPClient != null)
                {
                    if (nTCPClient.Client.Connected)
                    {
                        tx = Encoding.ASCII.GetBytes(tbPayload.Text);
                        nTCPClient.GetStream().BeginWrite(tx, 0, tx.Length, onCompleteWriteToClientStream, nTCPClient);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void onCompleteWriteToClientStream(IAsyncResult iar)
        {
            try
            {
                TcpClient tcpc = (TcpClient)iar.AsyncState;
                tcpc.GetStream().EndWrite(iar);
            }
            catch (Exception exc)
            {

                MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
