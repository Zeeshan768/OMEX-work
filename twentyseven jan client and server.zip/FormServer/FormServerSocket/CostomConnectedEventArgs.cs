﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net.Sockets;
using System.IO;

namespace FormServerSocket
{
    public class ClientConnectedEventArgs : EventArgs
    {
        public string NewClient { get; set; }
        public ClientConnectedEventArgs(string _newClient)
        {
            TextReceivedEventArgs a = new TextReceivedEventArgs("aaa","abc");   
            NewClient = _newClient;
        

        }
    }

    public class TextReceivedEventArgs : EventArgs
    {
        public string ClientWhoSentText { get; set; }
        public string TextReceived { get; set; }
        public TextReceivedEventArgs(string _clientWhoSentText, string _textReceived)
        {
            ClientWhoSentText = _clientWhoSentText;
            TextReceived = _textReceived;
        }
    }

    public class ConnectionDisconnectedEventArgs : EventArgs
    {
        public string DisconnectedPeer { get; set; }

        public ConnectionDisconnectedEventArgs(string _disconnectedPeer)
        {
            DisconnectedPeer = _disconnectedPeer;
        }

    }
}